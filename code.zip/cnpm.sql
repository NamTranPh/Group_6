-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 21, 2023 lúc 03:14 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `cnpm`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `managers`
--

CREATE TABLE `managers` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `managers`
--

INSERT INTO `managers` (`id`, `username`, `fullname`, `password`, `phone`, `email`, `address`) VALUES
(1, 'Nun', 'trung', '123456', '971845221', 'haha@gmail.com', 'HaNoi');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tour`
--

CREATE TABLE `tour` (
  `id` int(11) NOT NULL,
  `tourname` varchar(100) DEFAULT NULL,
  `price` decimal(15,0) DEFAULT NULL,
  `images` varchar(50) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tour`
--

INSERT INTO `tour` (`id`, `tourname`, `price`, `images`, `detail`, `manager_id`, `users_id`) VALUES
(1, ' Sapa - Ngỡ Lạc Giữa Trời Âu ', 500, './img/sp1.jpg', 'Hôtel de la Coupole - Mgallery được xem là “chuẩn mực của sự xa hoa” trong các khách sạn 5 sao hạng sang.“Trái tim” của khách sạn là hệ thống ẩm thực, với một nhà hàng Chic, một quầy bar Absinthe và một tiệm bánh ngọt đậm phong cách Pháp có tên Cacao,… Tất cả đều được phục vụ ở mức tốt nhất dành cho du khách. Đến Hôtel de la Coupole - Mgallery được thiết kế bởi kiến trúc sư lừng danh Bill Bensley - vị kiến trúc sư nổi tiếng với chuỗi những khách sạn boutique độc đáo trên thế giới.', 1, 1),
(2, 'Vịnh Hạ Long', 1200, './img/sp2.jpg', 'Vịnh Hạ Long với hàng nghìn đảo đá nhấp nhô trên sóng nước lung linh huyền ảo, những hang động tuyệt đẹp, những bãi tắm hoang sơ, làn nước mát lạnh trong veo đặt trưng của vùng đảo Cô Tô, Soi Sim, ...', 1, 1),
(3, 'Đà Nẵng - Huế ', 1300, './img/sp3.jpg', 'Phố cổ Hội An với lung linh sắc màu của đèn lồng và những hoạt động dân gian đặc sắc - Đại Nội Huế rộng lớn nơi hoàng cung xưa của các vua chúa Triều Nguyễn - Chùa Thiên Mụ - Biểu tượng xứ Huế mộng mơ.', 1, 1),
(4, 'Đà Nẵng - Bà Nà - Cầu Vàng', 1500, './img/sp4.jpg', 'Khu Tâm linh mới của Bà Nà viếng Đền Lĩnh Chúa Linh Từ, khu vui chơi Fantasy Park, tự do chụp hình tại Cầu Vàng điểm tham quan mới siêu hot tại Bà Nà…', 1, 1),
(5, 'Đà Nẵng - Phố cổ Hội An', 900, './img/sp5.jpg', 'Chùa Cầu, Nhà Cổ, Hội Quán, dạo phố đèn lồng cảm nhận sự yên bình, cổ kính, lãng mạn Hội An, thưởng thức đặc sản nổi tiếng địa phương  Cao Lầu, Mỳ Quảng, Cơm Gà,…. ', 1, 1),
(6, 'Nha Trang - Phú Yên', 1800, './img/sp6.jpg', 'Nha Trang – phố biển xinh đẹp với những thắng cảnh nổi tiếng mang đến giá trị văn hóa, lịch sử, giải trí hấp dẫn đang hòa chung nhịp đập với chương trình Festival Biển Nha Trang 2023 - “Khát Vọng Phát Triển”', 1, 1),
(7, 'Nha Trang - Làng Chài Xưa Mũi Né', 1200, './img/sp7.jpg', 'Nha Trang với khí hậu ôn hòa, biển xanh trong quanh năm cùng những điểm vui chơi bậc nhất và không ngừng đổi mới hằng ngày luôn thu hút du khách gần xa.', 1, 1),
(8, 'Phan Thiết - Mũi Né ', 800, './img/sp8.jpg', 'Một trong những khu vực đẹp nhất nằm ở Mũi Né thu hút khá nhiều du khách do hình dáng đẹp của cát và màu sắc của cát, nơi đây được xem là đồi cát có một không hai tại Việt Nam bắt nguồn từ mỏ sắt cổ tồn tại hàng trăm năm tạo nên.', 1, 1),
(9, 'Mộc Châu - Mai Châu - Điểm chạm đa sắc vùng Tây Bắc', 1500, './img/sp9.jpg', 'điểm đến di sản thiên nhiên khu vực hàng đầu thế giới tại Mường Sang, Mộc Châu, tọa lạc giữa thung lũng của vùng núi Tây Bắc, mang tới cho du khách cảm giác gần gũi với thiên nhiên cùng những trải nghiệm thắng cảnh - giải trí - ẩm thực đẳng cấp', 1, 1),
(10, 'Phú Quốc - Thiên đường giải trí Vinwonder', 2900, './img/sp10.jpg', 'Khu vui chơi giải trí VinWonders - Công viên chủ đề lớn nhất Việt Nam, quy mô hàng đầu Châu Á, du khách sẽ được:\r\n- Trải nghiệm 12 nền văn minh nhân loại từ cổ chí kim;\r\n- Khám phá 06 phân khu với hơn 100 hoạt động giải trí siêu độc lạ;\r\n- Cuồng nhiệt tại Công Viên Nước lớn nhất Đông Nam Á;', 1, 1),
(11, 'Phú Quốc: Hòn Thơm Nature Park', 1100, './img/sp11.jpg', 'Thỏa thích tắm biển Hòn Thơm: một trong những bãi biển “quyến rũ nhất hành tinh”, với bãi cát trắng mịn, hoang sơ, hàng dừa nghiêng soi bóng, màu nước biển xanh màu ngọc bích, phản chiếu long lanh dưới ánh nắng mặt trời.', 1, 1),
(12, 'Vũng Tàu - Sắc Màu Biển Xanh', 1200, './img/sp12.jpg', 'Bãi biển Thùy Vân (bãi sau Vũng Tàu): Quý khách hòa mình cùng dòng nước xanh mát hay phơi mình đón ánh nắng lung linh trên bãi cát vàng trải dài trong không khí nhộn nhịp nơi phố biển.', 1, 1),
(13, 'Tây Ninh - Vùng Đất Địa Linh ', 800, './img/sp13.jpg', 'Hành trình đoàn đến ‘vùng đất thánh Tây Ninh’ - nơi khởi phát của nhiều tín ngưỡng, tôn giáo đặc sắc với các điểm đến mang dấu ấn tín ngưỡng đặc biệt', 1, 1),
(14, 'Phước Hải: Trải Nghiệm Dịch Vụ 4 Sao Trân Châu Resort - Hồ Tràm', 1500, './img/sp14.jpg', 'Sống ảo với những điểm check-in siêu hot: Tháp Vọng Thiên và Cầu Tình Yêu - rực rỡ sắc đỏ, du khách phóng tầm mắt chiêm ngưỡng vẻ đẹp bao la của biển cả và tàu thuyền ngoài khơi xa', 1, 1),
(15, 'Tây Ninh - Hành trình chinh phục nóc nhà Nam Bộ', 1900, './img/sp15.jpg', 'Đến Quần thể danh thắng núi Bà Đen - nổi tiếng với cảnh sắc thiên nhiên hoang sơ và quần thể kiến trúc tâm linh lâu đời.', 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `fullname`, `password`, `phone`, `email`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Nun', 'trung', '123456789', '971845221', 'haha@gmail.com', 'HaNoi', '2023-12-21 08:27:10', '2023-12-21 08:31:43'),
(2, NULL, NULL, '$2y$12$B7.1BIdwhE9iTYUIQI1HjuQwf0CvYinF2y4QlyGQvAABUG88DgMKi', NULL, 'trungaming3@gmail.com', NULL, '2023-12-21 02:47:46', '2023-12-21 02:47:46');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tour`
--
ALTER TABLE `tour`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manager_id` (`manager_id`),
  ADD KEY `users_id` (`users_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `managers`
--
ALTER TABLE `managers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tour`
--
ALTER TABLE `tour`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `fk_account_id` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_account_managerid` FOREIGN KEY (`id`) REFERENCES `managers` (`id`);

--
-- Các ràng buộc cho bảng `tour`
--
ALTER TABLE `tour`
  ADD CONSTRAINT `tour_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `managers` (`id`),
  ADD CONSTRAINT `tour_ibfk_2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
