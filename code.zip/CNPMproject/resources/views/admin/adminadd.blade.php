<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <!-- css -->
    <link rel="stylesheet" href="{{ asset('css/admin/add.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin/admin.css') }}">
  <!-- font-awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
<main class="main-wrapper">
    <div id="mainNavbar" class="sidebar-wrapper ">
      <!--  SIDEBAR  -->
      <div class="sidebar-logo">
        <img src="https://pos.nvncdn.com/86c7ad-50310/art/artCT/20230420_0moA6KAt.png" height="70px" alt="">
        <p class="brand-name">Festivals</p>
      </div>
      <ul class="nav-block">
        <li class="nav-title" style="font-weight: 700;">
          ADMIN
        </li>
        <li class="nav-item nav-active">
          <a href="/admin">Trang chủ</a>
        </li>
        <li class="nav-item ">
          <a href="/adminadd">Thêm sản phẩm</a>
        </li>
        {{-- <li class="nav-item" style="background-color: rgba(227, 56, 56, 0.56);">
          <a href="/">Trang chủ</a>
        </li> --}}
      </ul>
      
    </div>
    <div class="container" style="height: 70%;">
        <h1>Thêm sản phẩm</h1>
        <div class="con">
            <form class="row g-3" method="post" action="/adminadd/store" enctype="multipart/form-data">
              @csrf
                <div class="col-md-6">
                  <label for="inputEmail4" class="form-label">Tên sản phẩm</label>
                  <input type="text" name="tourname" class="form-control" id="inputtensp">
                </div>
                <div class="col-md-6">
                  <label for="inputPassword4" class="form-label">Giá của tour</label>
                  <input type="text" name="price" class="form-control" id="inputPassword4">
                </div>
                <div class="form-floating">
                    <textarea class="form-control" name="detail" placeholder="Chi tiết sản phẩm" id="floatingTextarea2" style="height: 100px"></textarea>
                    <label for="floatingTextarea2">Chi tiết sản phẩm</label>
                </div>
                
                <div class="col-12">
                <div class="col-md-6">
                  <label for="inputPassword4" class="form-label">manager_id</label>
                  <input type="text" name="manager_id" class="form-control" id="inputPassword4">
                  </div>
                <div class="col-md-6">
                  <label for="inputPassword4" class="form-label">users_id</label>
                  <input type="text" name="users_id" class="form-control" id="inputPassword4">
                </div>
                <div class="col-md-4"style="margin-top: 1%">
                  <label for="inputState" class="form-label">Chọn ảnh</label>
                  <input type="file" name="image" />
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="gridCheck">
                    <label class="form-check-label" for="gridCheck">
                      Đồng ý với dữ liệu trên
                    </label>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary">Thêm sản phẩm</button>
                </div>
                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{ Session::get('success') }}
                    </div>
                @endif
              </form>
        </div>
    </div>
    </main>

<script src="{{ asset('js/admin/main.js') }}"></script>
</body>

</html>