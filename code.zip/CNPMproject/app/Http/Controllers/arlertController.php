<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class arlertController extends Controller
{
    public function alert(){
        return view('alert');
    }
}
