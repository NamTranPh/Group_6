<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Document</title>
  <!-- css -->
  <link rel="stylesheet" href="{{ asset('css/cardbook.css') }}">
  <!-- font-awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">


</head>

<body>
  <!-- Navigation -->
  <nav id="navbar" class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
      <a class="navbar-brand" href="/">Festivals</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="op navbar-nav ms-auto">
          <li class="nav-item active">
            <a class="nav-link" href="/">Trang chủ</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/login">Đăng nhập</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/register">Đăng kí</a>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>



  <div class="than" style="padding-top: 10%; padding-inline: 10%; padding-bottom: 10%; background-color: rgba(0, 0, 0, 0.5); ">
    <div class="conten1" style="background-color: rgb(214, 214, 214); ">
      <h3 class="aaa" style="text-align: center; padding-top: 30px;">{{$product->tourname}}</h3>
      <section class="gallery">
        <div class="gallery__item">
          <img style="width:fit-content" src="{{ asset($product->images) }}" alt="" />
        </div>
      </section>
      <p class="yyy" style="padding: 5%;">
        {{$product->detail}}
      </p>
    </div>
  </div>
  <!-- Footer -->
  <section class="foot">
    <footer class="footer-distributed">
      <!-- Left -->
      <div class="footer-left">
        <h3>Festivals<span>.com</span></h3>

        <p class="footer-links">
          <a href="index1.html">Home</a>
          |
          <a href="about.html">About</a>
          |
          <a href="contact.html">Contact</a>
          |
          <a href="prdList.html">Books</a>
        </p>

        <p class="footer-date-name">Started <strong>20/5/2023</strong></p>
      </div>
      <!-- Center -->
      <div class="footer-center">
        <div>
          <a href="https://www.google.com/maps/place/H%C3%A0+N%E1%BB%99i,+Vi%E1%BB%87t+Nam/@20.973184,105.0295149,10z/data=!3m1!4b1!4m6!3m5!1s0x3135008e13800a29:0x2987e416210b90d!8m2!3d21.0031177!4d105.8201408!16s%2Fg%2F11clt0ky_h?entry=ttu"><i class="fa-solid fa-location-dot"></i></a>
          <p><span>Hà Nội</span>Việt Nam</p>
        </div>

        <div>
          <i class="fa-solid fa-phone"></i>
          <p>+84 987654321</p>
        </div>
        <div>
          <i class="fa-solid fa-envelope"></i>
          <p><a href="#">G2.Aptech@gmail.com</a></p>
        </div>
      </div>
      <!-- Right  -->
      <div class="footer-right">
        <p class="footer-follow">
          <span>Follow Us</span>
          <strong>Festivals.com</strong>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora ut, perferendis aut atque saepe sequi dolorum
          sint velit pariatur non facere blanditiis officiis!
        </p>
        <div class="footer-icons">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-youtube"></i></a>
          <a href="#"><i class="fa-brands fa-tiktok"></i></a>
        </div>
      </div>
    </footer>
  </section>
  <!-- Footer -->
</body>
<!-- Link script -->
<script src="./js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</html>