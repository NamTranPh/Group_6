<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\Admin;
use App\Http\Controllers\CartController;
class AdminAdd extends Model
{
    use HasFactory;
    protected $table = 'tour';
    protected $fillable = ['tourname', 'price', 'images', 'detail','manager_id','users_id'];
    public $timestamps = false;
}
