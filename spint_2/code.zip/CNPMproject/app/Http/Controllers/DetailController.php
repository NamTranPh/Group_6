<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class DetailController extends Controller
{
    public function show($id)
    {
        $product = Product::findOrFail($id);
        $comments = Comment::where('tour_id', $id)->with('user')->get();

        return view('detail', compact('product', 'comments'));
    }

    public function store(Request $request, $id)
    {
        $request->validate([
            'message' => 'required',
        ]);

        $comment = new Comment();
        $comment->user_id;
        $comment->tour_id = $id;
        $comment->comments = $request->input('message');
        $comment->save();

        return redirect()->back()->with('success', 'Comment added successfully.');
    }
    public function showComments()
{
    $comments = Comment::with('user')->get(); // Lấy tất cả đánh giá với thông tin người dùng
    return view('detail', compact('comments'));
}
}
