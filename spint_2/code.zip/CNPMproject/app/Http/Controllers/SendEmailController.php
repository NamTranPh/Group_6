<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\NotifyMail;
use Illuminate\Support\Facades\Mail;

class SendEmailController extends Controller
{
    public function show(){
        return view('/payment');
    }
    public function sendmail(Request $request){
        $email=$request->email;
        Mail::to($email)->send(new SendMail());
        return view('/');
    }
}
