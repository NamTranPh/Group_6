function clickme(smallImg){

    let fullImg =  document.getElementById("imgBox");
    fullImg.src = smallImg.src;
}