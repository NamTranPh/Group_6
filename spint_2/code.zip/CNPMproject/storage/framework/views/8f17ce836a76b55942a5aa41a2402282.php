<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Đăng nhập</title>

    <!-- Link fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Link css -->
    <link rel="stylesheet" type="text/css" href=" <?php echo e(url('/css/login.css')); ?> ">
</head>

<body>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="forms-container">
            <div class="login-register">
                <form method="POST" action="<?php echo e(route('login')); ?>" class="login-form">
                    <?php echo csrf_field(); ?>
                    <h2 class="title">Đăng nhập</h2>
                    <div class="input-field">
                        <label for="email"><i class="fas fa-user"></i></label>
                        <input id="email" type="text" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Nhập tài khoản">
                        
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="input-field">
                        <label for="password"><i class="fas fa-lock"></i></label>
                        <input id="password" type="password"
                            class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="password" required autocomplete="current-password" placeholder="Nhập mật khẩu">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <a style="width:200px" href="/alert">
                        <input type="submit" value="<?php echo e(__('Đăng nhập')); ?>" class="btn-login">
                    </a>    
                </form>
            </div>
        </div>

        <div class="panels-container">
            <div class="panel left-panel">
                <div class="content">
                    <h2>Bạn chưa có tài khoản ?</h2>
                    <p>Hãy gia nhập cùng chúng tôi để có thể trải nghiệm những chuyến đi thú vị. Gia nhập bằng cách ấn nút phía dưới</p>
                    
                    <a class="btn-transparent" href="<?php echo e(route('register')); ?>"><?php echo e(__('Đăng ký')); ?></a>
                </div>
                <img src="./Img/login.svg" class="image" alt="">
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</body>
<script src=" <?php echo e(url('/js/login.js')); ?> "></script>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aptech\cnpm\CNPMproject\resources\views/auth/login.blade.php ENDPATH**/ ?>