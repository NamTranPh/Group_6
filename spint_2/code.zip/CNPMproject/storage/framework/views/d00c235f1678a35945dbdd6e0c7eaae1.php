<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thống kê doanh thu - Quản trị viên</title>
  <!-- css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/admin/admin.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/admin/statistics.css')); ?>">
  <!-- font-awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
  <div class="d-flex">
    <main class="main-wrapper">
      <div id="mainNavbar" class="sidebar-wrapper ">
        <!--  SIDEBAR  -->
        <div class="sidebar-logo">
          <img src="https://pos.nvncdn.com/86c7ad-50310/art/artCT/20230420_0moA6KAt.png" height="70px" alt="">
          <p class="brand-name">Festivals</p>
        </div>
        <ul class="nav-block">
          <li class="nav-title" style="font-weight:700;">
            ADMIN
          </li>
          <li class="nav-item">
            <a href="/admin">Trang chủ Admin</a>
          </li>
          <li class="nav-item">
            <a href="/adminadd">Thêm sản phẩm</a>
          </li>
          <li class="nav-item nav-active">
            <a href="/statistics">Thống kê doanh thu</a>
          </li>
        </ul>

      </div>
    </main>

    <div class="container">
      <h1 class="statistics-title">Thống kê doanh thu</h1>

      <div id="overview">
        <h3>Tổng thu nhập</h3>
        <div class="d-flex">
          <p>- Tổng doanh thu:</p>
          <p style="padding: 0 10px;"></p>
          <p><?php echo e(Cart::getTotal()); ?> $</p>
        </div>
        <div class="d-flex">
          <p>- Tổng số tour đã đặt:</p>
          <p style="padding: 0 10px;"></p>
          <p><?php echo e(Cart::getTotalQuantity()); ?> </p>
        </div>
      </div>

      <div id="top-performers">
        <h3>Tour thịnh hành</h3>
        <ul>
          <li>
            <img class="img-performers" src="https://file1.dangcongsan.vn/data/0/images/2023/04/19/upload_4752/5.jpg" alt="img">
            <div>
              <p>Cầu Vàng (Bà Nà Hills, Đà Nẵng) – một trong những công trình làm nên biểu tượng mới của du lịch Việt Nam </p>
            </div>
          </li>
          <li>
            <img class="img-performers" src="https://c4.wallpaperflare.com/wallpaper/267/771/755/photography-h%E1%BA%A1-long-bay-boat-earth-wallpaper-preview.jpg" alt="img">
            <div>
              <p>Vịnh Hạ Long với hàng nghìn đảo đá nhấp nhô trên sóng nước lung linh huyền ảo, những hang động tuyệt đẹp</p>
            </div>
          </li>
        </ul>
      </div>

      <div id="details">
        <h3>Báo cáo chi tiết</h3>
        <table class="table" id="mytable">
          <thead>
            <tr>
              <th scope="col">ID Tour</th>
              <th scope="col">Tên Tour</th>
              <th scope="col">Giá</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($row->id); ?></td>
              <td><?php echo e($row->tourname); ?></td>
              <td><?php echo e($row->price); ?> $</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
<script src="<?php echo e(asset('js/admin/main.js')); ?>"></script>

<script src="cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js">
  let table = new DataTable('#myTable');
</script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

</html><?php /**PATH D:\ki1_nam2\BaiTapLonCNPM\CNPMproject\resources\views/admin/statistics.blade.php ENDPATH**/ ?>