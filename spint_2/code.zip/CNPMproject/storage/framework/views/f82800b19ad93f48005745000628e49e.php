<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=, initial-scale=1.0">
  <title>Document</title>
  <!-- css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/detail.css')); ?>">
  <!-- font-awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <!-- Link Boxicon-->
  <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
</head>

<body>
  <!-- Navbar -->
  <nav id="navbar" class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
      <a class="navbar-brand" href="/">Festivals</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <form class="d-flex" style="margin: 0px 0px 0px 160px" action="<?php echo e(route('search')); ?>" method="GET">
        <input class="form-control me-2" type="search" placeholder="Tìm kiếm nhanh" aria-label="Search" style="width: 500px ; font-size: 20px;" name="search" />
        <button class="btn btn-success" type="submit">Tìm kiếm</button>
      </form>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="op navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="/"><i class='bx bx-home'></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/login"><i class='bx bx-user'></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href=""><i class='bx bx-cart'></i></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <div class="detail-body"
    style="padding-top: 10%; padding-inline: 10%; padding-bottom: 10%; background-color: rgba(0, 0, 0, 0.5); ">
    <div class="conten1" style="background-color: rgb(214, 214, 214); ">
      <h3 class="tour-title" style="text-align: center; padding-top: 30px;"><?php echo e($product->tourname); ?></h3>
      
        <div class="gallery__item">
          <img style="width:fit-content" src="<?php echo e(asset($product->images)); ?>" alt="" />
        </div>
      
      <p class="tour-info"><?php echo e($product->detail); ?></p>
      <div class="d-flex detail-price">
        <p>Giá: </p>
        <p><?php echo e($product->price); ?>$</p>
      </div>
      <div class="button-center">
        <form action="<?php echo e(route('addCart')); ?>" method ="POST" enctype="mutipart/form-data">
          <?php echo csrf_field(); ?>
          <input type="hidden" value="<?php echo e($product->id); ?>"name="id">
          <input type="hidden" value="<?php echo e($product->tourname); ?>"name="tourname">
          <input type="hidden" value="<?php echo e($product->price); ?>"name="price">
          <input type="hidden" value="<?php echo e($product->images); ?>"name="images">
          <button type="submit" class="btn-buy" >Đặt Tour</button>
        </form>
      </div>
    </div>

    <!--  -->
    <hr class="line">
    <!--  -->
    <div class="review">
      <h5>Đánh giá từ khách hàng</h5>
      <div class="row">
        <div>
          
          <div class="col">
            <div class="img-review col-md-1">
              <img src="/Img/user1.jpg" alt="">
            </div>
            <div class="content-review col-md-11">
              <p>Tên tài khoản khách hàng</p>
              <p>Mô tả đánh giá</p>
            </div>
          </div>
          
        </div>
      </div>
    </div>

    <!--  -->
    <div class="form-comment">
      <div class="row">
        <div class="col">
          <p class="title">Đánh giá</p>
          <div class="form-cmt">
            <form action="" method="POST">
              
              <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
              <div class="textCmtBox">
                <p>Nhận xét của bạn (*):</p>
                <textarea name="message"></textarea>
                
              </div>
              <div>
                <button class="button-submit" type="submit">Gửi phản hồi</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <section class="foot">
    <footer class="footer-distributed">
      <!-- Left -->
      <div class="footer-left">
        <h3>Festivals<span>.com</span></h3>

        <p class="footer-links">
          <a href="index.html">Trang chủ</a>
          |
          <a href="about.html">Chúng tôi</a>
          |
          <a href="contact.html">Liên hệ</a>
          |
          <a href="books.html">Chi tiết</a>
        </p>

        <p class="footer-date-name">Started <strong>20/5/2023</strong></p>
      </div>
      <!-- Center -->
      <div class="footer-center">
        <div>
          <i class="fa-solid fa-location-dot"></i>
          <p><span>Hà Nội</span>Việt Nam</p>
        </div>

        <div>
          <i class="fa-solid fa-phone"></i>
          <p>+84 943178267</p>
        </div>
        <div>
          <i class="fa-solid fa-envelope"></i>
          <p>G2.Aptech@gmail.com</p>
        </div>
      </div>
      <!-- Right  -->
      <div class="footer-right">
        <p class="footer-follow">
          <span>Folow chúng tôi</span>
          <strong>Festivals.com</strong>
          Hãy kết nối với chúng tôi để cập nhật những tin tức mới nhất,
          thông tin hữu ích và các cập nhật khác. Đừng bỏ lỡ bất kỳ điều gì quan trọng!
        </p>
        <div class="footer-icons">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-youtube"></i></a>
          <a href="#"><i class="fa-brands fa-tiktok"></i></a>
        </div>
      </div>
    </footer>
  </section>
  <!-- Footer -->
</body>
<!-- Link script -->
<script src="./js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</html><?php /**PATH C:\Aptech\cnpm\CNPMproject\resources\views/detail.blade.php ENDPATH**/ ?>