-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 28, 2023 lúc 07:47 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `cnpm`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `managers`
--

CREATE TABLE `managers` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `managers`
--

INSERT INTO `managers` (`id`, `username`, `fullname`, `password`, `phone`, `email`, `address`) VALUES
(1, 'Nun', 'trung', '123456', '971845221', 'haha@gmail.com', 'HaNoi');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tour`
--

CREATE TABLE `tour` (
  `id` int(11) NOT NULL,
  `tourname` varchar(100) DEFAULT NULL,
  `price` decimal(15,0) DEFAULT NULL,
  `images` varchar(500) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `users_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tour`
--

INSERT INTO `tour` (`id`, `tourname`, `price`, `images`, `detail`, `manager_id`, `users_id`) VALUES
(1, ' Sapa - Ngỡ Lạc Giữa Trời Âu ', 500, './img/sp1.jpg', 'Hotel de la Coupole - Mgallery được xem là “chuẩn mực của sự xa hoa” trong các khách sạn 5 sao hạng sang.“Trái tim” của khách sạn là hệ thống ẩm thực, với một nhà hàng Chic, một quầy bar Absinthe và một tiệm bánh ngọt đậm phong cách Pháp có tên Cacao,… Tất cả đều được phục vụ ở mức tốt nhất dành cho du khách. Đến Hôtel de la Coupole - Mgallery được thiết kế bởi kiến trúc sư lừng danh Bill Bensley - vị kiến trúc sư nổi tiếng với chuỗi những khách sạn boutique độc đáo trên thế giới.', 1, 1),
(2, 'Vịnh Hạ Long', 1200, './img/sp2.jpg', 'Vịnh Hạ Long với hàng nghìn đảo đá nhấp nhô trên sóng nước lung linh huyền ảo, những hang động tuyệt đẹp, những bãi tắm hoang sơ, làn nước mát lạnh trong veo đặt trưng của vùng đảo Cô Tô, Soi Sim, ...', 1, 1),
(3, 'Đà Nẵng - Huế ', 1300, './img/sp3.jpg', 'Phố cổ Hội An với lung linh sắc màu của đèn lồng và những hoạt động dân gian đặc sắc - Đại Nội Huế rộng lớn nơi hoàng cung xưa của các vua chúa Triều Nguyễn - Chùa Thiên Mụ - Biểu tượng xứ Huế mộng mơ.', 1, 1),
(4, 'Đà Nẵng - Bà Nà - Cầu Vàng', 1500, './img/sp4.jpg', 'Khu Tâm linh mới của Bà Nà viếng Đền Lĩnh Chúa Linh Từ, khu vui chơi Fantasy Park, tự do chụp hình tại Cầu Vàng điểm tham quan mới siêu hot tại Bà Nà…', 1, 1),
(5, 'Đà Nẵng - Phố cổ Hội An', 900, './img/sp5.jpg', 'Chùa Cầu, Nhà Cổ, Hội Quán, dạo phố đèn lồng cảm nhận sự yên bình, cổ kính, lãng mạn Hội An, thưởng thức đặc sản nổi tiếng địa phương  Cao Lầu, Mỳ Quảng, Cơm Gà,…. ', 1, 1),
(6, 'Nha Trang - Phú Yên', 1800, './img/sp6.jpg', 'Nha Trang – phố biển xinh đẹp với những thắng cảnh nổi tiếng mang đến giá trị văn hóa, lịch sử, giải trí hấp dẫn đang hòa chung nhịp đập với chương trình Festival Biển Nha Trang 2023 - “Khát Vọng Phát Triển”', 1, 1),
(7, 'Nha Trang - Làng Chài Xưa Mũi Né', 1200, './img/sp7.jpg', 'Nha Trang với khí hậu ôn hòa, biển xanh trong quanh năm cùng những điểm vui chơi bậc nhất và không ngừng đổi mới hằng ngày luôn thu hút du khách gần xa.', 1, 1),
(8, 'Phan Thiết - Mũi Né ', 800, './img/sp8.jpg', 'Một trong những khu vực đẹp nhất nằm ở Mũi Né thu hút khá nhiều du khách do hình dáng đẹp của cát và màu sắc của cát, nơi đây được xem là đồi cát có một không hai tại Việt Nam bắt nguồn từ mỏ sắt cổ tồn tại hàng trăm năm tạo nên.', 1, 1),
(9, 'Mộc Châu - Mai Châu - Điểm chạm đa sắc vùng Tây Bắc', 1500, './img/sp9.jpg', 'Điểm đến di sản thiên nhiên khu vực hàng đầu thế giới tại Mường Sang, Mộc Châu, tọa lạc giữa thung lũng của vùng núi Tây Bắc, mang tới cho du khách cảm giác gần gũi với thiên nhiên cùng những trải nghiệm thắng cảnh - giải trí - ẩm thực đẳng cấp', 1, 1),
(10, 'Phú Quốc - Thiên đường giải trí Vinwonder', 2900, './img/sp10.jpg', 'Khu vui chơi giải trí VinWonders - Công viên chủ đề lớn nhất Việt Nam, quy mô hàng đầu Châu Á, du khách sẽ được:\r\n- Trải nghiệm 12 nền văn minh nhân loại từ cổ chí kim;\r\n- Khám phá 06 phân khu với hơn 100 hoạt động giải trí siêu độc lạ;\r\n- Cuồng nhiệt tại Công Viên Nước lớn nhất Đông Nam Á;', 1, 1),
(11, 'Phú Quốc: Hòn Thơm Nature Park', 1100, './img/sp11.jpg', 'Thỏa thích tắm biển Hòn Thơm: một trong những bãi biển “quyến rũ nhất hành tinh”, với bãi cát trắng mịn, hoang sơ, hàng dừa nghiêng soi bóng, màu nước biển xanh màu ngọc bích, phản chiếu long lanh dưới ánh nắng mặt trời.', 1, 1),
(12, 'Vũng Tàu - Sắc Màu Biển Xanh', 1200, './img/sp12.jpg', 'Bãi biển Thùy Vân (bãi sau Vũng Tàu): Quý khách hòa mình cùng dòng nước xanh mát hay phơi mình đón ánh nắng lung linh trên bãi cát vàng trải dài trong không khí nhộn nhịp nơi phố biển.', 1, 1),
(13, 'Tây Ninh - Vùng Đất Địa Linh ', 800, './img/sp13.jpg', 'Hành trình đoàn đến ‘vùng đất thánh Tây Ninh’ - nơi khởi phát của nhiều tín ngưỡng, tôn giáo đặc sắc với các điểm đến mang dấu ấn tín ngưỡng đặc biệt', 1, 1),
(14, 'Rạch Giá - Tây Ninh - Hành Trình Chinh Phục Nóc Nhà Nam Bộ', 1200, './img/sp14.jpg', 'nổi tiếng với cảnh sắc thiên nhiên hoang sơ và quần thể kiến trúc tâm linh lâu đời. Bên cạnh đó, du khách có thể check-in nhà ga cáp treo lớn nhất thế giới, với tuyến cáp treo hiện đại khiến cho hành trình chiêm bái và chinh phục ngọn núi cao nhất Nam Bộ của du khách thập phương trở nên dễ dàng hơn bao giờ hết.', 1, 1),
(15, 'Nha Trang - Làng Chài Xưa Mũi Né - Biển Nhũ Tiên - Suối khoáng nóng', 1300, './img/sp15.jpg', 'Nha Trang với khí hậu ôn hòa, biển xanh trong quanh năm cùng những điểm vui chơi bậc nhất và không ngừng đổi mới hằng ngày luôn thu hút du khách gần xa. Đến với Nha Trang, du khách không chỉ tận hưởng những đợt gió biển trong nắng ấm mà còn có dịp thưởng thức hải sản tươi ngon cùng sự chào đón nồng hậu từ những người dân vùng biển nghĩa tình, cho Quý khách trải nghiệm khó quên tại vùng đất này.', 1, 1),
(16, 'HÀ NỘI – CÔ TÔ “CHUYỆN TÌNH ĐẢO NHỎ”', 1500, './img/sp16.jpg', '1 - Đầy đủ các điểm đến hấp dẫn nhất: Biển Hồng Vàn, Vàn Chảy, bãi đá Cầu Mỵ, rừng chõi, đường tình yêu, hải đăng Cô Tô, tượng đài Bác Hồ... \r\n2 - Xe ô tô 35, 45 chỗ và tàu cao tốc đời mới nhất.\r\n3 - Khách sạn 3* sang trọng, vị trí trung tâm.\r\n4 - Bữa ăn chất lượng nhất với đặc sản biển tươi ngon của vùng biển Quảng Ninh.\r\n5 - Được tặng áo cờ đỏ sao vàng miễn phí để chụp ảnh thể hiện tình yêu biển đảo Tổ quốc. \r\n6 - Tham gia chương trình ý nghĩa “Chuyện tình đảo nhỏ” để giữ mãi màu xanh Cô Tô.', 1, 1),
(17, 'HÀ NỘI – HÀ GIANG – BA BỂ - CAO BẰNG – LẠNG SƠN – HÀ NỘI', 2000, './img/sp17.jpg', 'NGÀY 01: HÀ NỘI – HÀ GIANG – QUẢN BẠ - YÊN MINH\r\n- Sáng 05h00: Xe ô tô và HDV của Văn Hóa & DL Hà Nội đón Quý khách tại điểm hẹn khởi hành đi Hà Giang. Trên đường đi quý khách dừng chân nghỉ ngơi, ăn sáng tại nhà hàng (chi phí tự túc). Sau bữa sáng đoàn tiếp tục hành trình cùng HDV khám phá các địa danh lịch sử, văn hóa mỗi vùng đất quý khách đi qua. Tham gia các hoạt động vui chơi giải trí do HDV tổ chức.\r\n- Trưa 11:00: Quý khách dùng cơm trưa tại nhà hàng. Sau bữa trưa đoàn khởi hành đi Yên Minh.\r\n- Chiều 14:00: Đến thành phố Hà Giang, quý khách chụp hình kỷ niệm tại Km0 của Hà Giang.\r\n- 15:30: Dừng chân tại điểm dừng chân Cổng Trời Quản Bạ chụp hình Núi đôi Cô Tiên hay còn gọi là Núi đôi Quản Bạ và toàn cảnh thị trấn Tam Sơn từ trên cao.\r\n- 16:30: Đến Yên Minh, Quý khách nhận phòng nghỉ ngơi sau một hành trình dài.\r\n- Tối 19:00: Quý khách dùng cơm tối tại nhà hàng với các món ăn ngon mang đậm hương vị của núi rừng Đông Bắc. Sau bữa tối đoàn tự do tham quan khám phá thị trấn Yên Minh về đêm.\r\nNghỉ Đêm Tại Yên Minh\r\nNGÀY 02: YÊN MINH – DINH NHÀ VƯƠNG – CỘT CỜ LŨNG CÚ – ĐỒNG VĂN\r\n- Sáng 06:00: Quý khách làm thủ tục trả phòng khách sạn, dùng điểm tâm sáng tại nhà hàng.\r\n- 07:00: Sau bữa sáng xe đón quý khách khởi hành tới tham quan dinh thự Vua Mèo. \r\n- 08:00: Tới dinh thự Vua Mèo quý khách bước vào hành trình khám phá toà dinh thự của thủ lĩnh người H\'Mông - Vương Chính Đức toạ lạc trên một ngọn đồi hình lưng con rùa, xung quanh là những dãy núi bao bọc... Rất nhiều thợ giỏi và nhân công miệt mài xây dựng không kể ngày đêm trong vòng 5 \r\nnăm liên tục và kinh phí hết khoảng 15.000 đồng bạc hoa xoè (tương đương 150 tỷ đồng hiện nay) mới hoàn thành.\r\n- 09:00: Xe đón quý khách khởi hành đi Lũng Cú chinh phục cực Bắc thiêng liêng của tổ quốc.\r\n- 10:00: Tới Lũng Cú quý khách tham quan và chụp ảnh lưu niệm tại chân cột cờ Lũng Cú. Báu vật ở thung lũng hoa tươi đẹp này không phải là mật ong có màu trong vắt, không phải là những chiếc áo dệt của người Mông hay là thung lũng hoa tam giác mạch đẹp diệu kỳ. Báu vật của Lũng Cú chính là lá cờ Tổ quốc rộng 54m2 (6x9m) gắn với ý nghĩa 54 dân tộc anh em một nhà. Nhiều đoàn công tác đến Lũng Cú đã được tặng lá cờ để mang về đặt trong phòng truyền thống nhằm giáo dục tinh thần yêu nước cho toàn đơn vị.\r\n- 11:00: Kết thúc chương trình tham quan, xe đưa quý khách về thị trấn Đồng Văn.\r\n- Trưa 12:00: Quý khách dùng cơm trưa tại nhà hàng. Sau bữa trưa đoàn nhận phòng khách sạn nghỉ ngơi.\r\n- Chiều: Quý khách tự do tham quan khám phá thị trấn Đồng Văn.\r\n- Tối 18:30: Quý khách dùng cơm tối tại nhà hàng. Sau bữa tối đoàn nghỉ ngơi tại khách sạn.\r\nNghỉ Đêm Tại Đồng Văn\r\nNGÀY 03: ĐỒNG VĂN – MÃ PÍ LÈNG – MÈO VẠC – BA BỂ\r\n- Sáng 06:00: Quý khách làm thủ tục trả phòng khách sạn, dùng điểm tâm sáng tại nhà hàng.\r\n- 07:00: Xe đón quý khách khởi hành tham quan Mã Pí Lèng một trong tứ đại đỉnh đèo của Việt Nam. Ngắm dòng sông Nho Quê bốn mùa nước xanh màu ngọc bích. \r\n- 08:30: Quý khách lên xe tiếp tục hành trình.\r\n- Trưa 12:00: Tới thành phố Hà Giang quý khách dùng cơm trưa tại nhà hàng.\r\n- Chiều 13:00 Khởi hành đi Ba Bể - Bắc Cạn.\r\n- 17:30: Tới Ba Bể quý khách nhận phòng khách sạn nghỉ ngơi.\r\n- Tối 19:00: Quý khách dùng cơm tối tại nhà hàng, sau bữa tối tự do tham quan khám phá Ba Bể về đêm. Quý khách nghỉ đêm tại khách sạn.\r\nNGÀY 04: BA BỂ - CAO BẰNG\r\n- Sáng 07:00: Quý khách dùng điểm tâm sáng tại nhà hàng. Sau bữa sáng HDV đưa khách xuống thuyền gỗ thăm quan hồ Ba Bể - Hồ thiên tạo lớn nhất Việt nam, thăm quan :  ao Tiên, Đảo Bà Góa - một hồ nước trong xanh huyền ảo nằm trên đỉnh núi đá vôi, tương truyền đây là nơi ngày xưa các tiên nữ thường xuống chơi cờ và tắm … Quý khách ngắm những thác nước kỳ vỹ, thung lũng sâu thẳm, hang động tự nhiên và hồ nhỏ. \r\n- Trưa 11:00: Quý khách làm thủ tục trả phòng khách sạn. Dùng cơm trưa tại nhà hàng.\r\n- 12:30: Quý khách khởi hành đi Cao Bằng.\r\n- 15:30: Tới Cao Bằng quý khách nhận phòng khách sạn nghỉ ngơi.\r\n- Tối 19:00: Quý khách dùng cơm tối tại nhà hàng. Sau bữa tối đoàn tự do tham quan khám phá thành phố Cao Bằng về đêm.\r\nNghỉ Đêm Tại Cao Bằng\r\nNGÀY 05: CAO BẰNG – THÁC BẢN GIỐC – ĐỘNG NGƯỜM NGAO\r\n- Sáng 07:00: Quý khách dùng điểm tâm sáng tại khách sạn. \r\n- 08:00: Xe đón quý khách khởi hành đi Trùng Khánh – Cao Bằng nơi có địa danh thác Bản Giốc được thiên nhiên ban tặng cho đất và người nơi đây.\r\n- 10:00: Tới thác Bản Giốc quý khách sẽ được tận mắt chiêm ngưỡng 1 trong 10 thác nước hùng vĩ nhất thế giới. Thác Bản Giốc thuộc lãnh thổ Việt Nam nằm tại xã Đàm Thủy, huyện Trùng Khánh, cách thành phố Cao Bằng gần 90 km. Đường dẫn tới thác quanh co, uốn lượn với khúc cua hẹp, không khí trong lành và phong cảnh đồng quê vùng núi trù phú. Dòng thác trắng xóa từ trên cao đổ xuống ào ào qua mấy tầng bụi mù hơi nước. Những núi đá vôi sừng sững hai bên góp phần làm nổi bật vẻ đẹp hoang sơ kỳ vĩ của dòng thác.\r\n- 11:00: Quý khách tham quan động Ngườm Ngao. Cách thác Bản Giốc không xa, quý khách sẽ được chiêm ngưỡng vẻ đẹp huyền bí của động Ngườm Ngao. Với hệ thống thạch nhũ và măng đá kỳ thú, đây là hang động đã được xếp vào hàng đẹp nhất Việt Nam.\r\nĐường tham quan trong Ngườm Ngao dài khoảng 2 km, vào bằng cửa Ngườm Lồm và ra bằng cửa Ngườm Ngao. Lối đi này trải bê tông, có đèn sáng. Tuy nhiên, đường đi này bị đứt quãng ở đoạn giữa hang - nơi trần hang cao nhất.\r\n- Trưa 12:00: Quý khách dùng cơm trưa tại nhà hàng.\r\n- 13:00: Xe đón quý khách khởi hành về lại Cao Bằng quý khách nhận phòng nghỉ ngơi.\r\n- Tối 19:00: Quý khách dùng cơm tối tại nhà hàng. Sau bữa tối đoàn tự do tham quan khám phá thành phố Cao Bằng về đêm.\r\nNghỉ Đêm Tại Cao Bằng\r\nNGÀY 06: CAO BẰNG – PẮC BÓ – KHU TƯỞNG NIỆM KIM ĐỒNG\r\n- Sáng 07:00: Quý khách làm thủ tục trả phòng khách sạn, dùng điểm tâm sáng tại nhà hàng. \r\n- 08:00: Xe đón quý khách khởi hành đi Pắc Bó một địa danh lịch sử cho thể hệ hôm nay và mai sau.\r\n- 09:00: Tới Pắc Bó. Khu Di tích lịch sử Pác Bó thuộc xã Trường Hà, huyện Hà Quảng, tỉnh Cao Bằng, sát biên giới với Trung Quốc. Đây là khu di tích gồm nhiều điểm di tích gắn với một thời kỳ lịch sử đặc biệt quan trọng trong cuộc đời hoạt động của Chủ tịch Hồ Chí Minh và cách mạng Việt Nam những năm 1941- 1945, thời kỳ chuẩn bị Tổng khởi nghĩa giành chính quyền trong cả nước. Khu Di tích được Nhà nước công nhận ngày 21-1-1975. Ngày 10-5-2012 Khu Di tích Pác Bó được công nhận là Di tích quốc gia đặc biệt.\r\n- 10:00: Xe đón quý khách tới viếng thăm mộ anh Kim Đồng.\r\n- Trưa 11:30: Quý khách dùng cơm trưa tại nhà hàng. Sau bữa trưa đoàn khởi hành đi Lang Sơn.\r\n- 15:30: Tới Lạng Sơn quý khách nhận phòng khách sạn nghỉ ngơi.\r\n- Tối 19:00: Quý khách dùng cơm tối tại nhà hàng, sau bữa tối đoàn tự do tham quan khám phá thành phố Lạng Sơn về đêm.\r\nNghỉ Đêm Tại Lạng Sơn.\r\nNGÀY 07: TAM THANH – NHỊ THANH – CHỢ ĐÔNG KINH – HÀ NỘI\r\n- Sáng 07:00: Quý khách làm thủ tục trả phòng khách sạn, dùng điểm tâm sáng tại nhà hàng.\r\n- 08:00: Xe và HDV đón quý khách tham quan quần thể danh thắng tiêu biểu của xứ Lạng là Tam Thanh và Nhị Thanh. Kết thúc chương trình xe đưa quý khách tới chợ Đông Kinh tham quan, và mua các mặt hàng thiết yếu về làm quà cho gia đình và người thân.\r\n- Trưa 11:30: Quý khách dùng cơm trưa tại nhà hàng.\r\n- 12:30: Xe đưa quý khách khởi hành về Hà Nội.\r\n- 17:30: Về tới Hà Nội, HDV chia tay đoàn và hẹn gặp lại đoàn trong những chuyến đi sau.', 1, 1),
(18, 'VƯỜN QUỐC GIA BA VÌ', 600, './img/sp18.jpg', 'Tại đây Quý khách tự do tham quan Vườn Xương Rồng Ba Vì. Trong vườn Xương Rồng trồng rất nhiều loài cây xương rồng khác nhau, đa dạng và đầy màu sắc trong đó có không ít loài xương rồng quý hiếm, độc đáo và lạ mắt. Vườn có hơn ngàn cây xương rồng với nhiều kích thước khác nhau, có những cây xương rồng to và cao hơn đầu người nhưng cũng có những cây nhỏ bé vô cùng xinh xắn.\r\n\r\nSau vườn Xương Rồng, điểm dừng chân thứ 2 du khách nên đến tham quan chính là Đồi Hoa Cúc Quỳ. Đồi Hoa Cúc Quỳ được tạo thành bởi hàng ngàn cây hoa cúc quỳ được người Pháp trồng từ thế kỉ trước.\r\n\r\nVào mùa hoa nở, cả đồi Hoa Cúc Quỳ tràn ngập trong màu vàng rực rỡ rất đẹp.', 1, 1),
(19, 'HÀ NỘI - HẠ LONG - HÀ NỘI', 1400, './img/sp19.jpg', 'NGÀY 01: HÀ NỘI – HẠ LONG\r\n- Sáng 07h00: Xe và HDV đón quý khách tại điểm hẹn khởi hành chuyến tham quan du lịch Hạ Long. Trên đường đi quý khách dừng chân tự do ăn sáng ở Sao Đỏ - Hải Dương. Sau bữa sáng đoàn lên xe tiếp tục hành trình.\r\n- Trưa 11h30: Đến nhà hàng tại Hạ Long quý khách dùng cơm trưa với các mon ăn đặc sản của vùng biển Quảng Ninh. Sau bữa trưa quý khách nhận phòng nghỉ ngơi.\r\n- Chiều: Quý khách tự do tắm biển hoặc dạo chơi biển Hạ Long, khám phá cảnh thiên nhiên cũng như tìm hiểu đời sống của người dân miền biển nơi đây.\r\n- Tối 19h00: Quý khách dùng cơm tối tại nhà hàng và tham dự tiệc Gala dinner “HẠ LONG – KHÚC TÌNH CA CỦA BIỂN” do công ty tổ chức với nhiều tiết mục hay và đặc sắc, cùng nhiều phần quà hấp dẫn trao tặng quý khách, hứa hẹn sẽ mang đến một đêm thật nhiều niềm vui và cảm xúc thăng hoa, kết thúc chương trình quý khách tự do tham quan khám phá Sầm Sơn về đêm. Quý khách nghỉ đêm tại khách sạn.\r\nNghỉ đêm tại Bãi Cháy\r\nNGÀY 02: KHÁM PHÁ VỊNH HẠ LONG\r\n- Sáng 07h00: Quý khách dùng điểm tâm Buffet tại nhà hàng. Sau bữa sáng xe đón quý khách khởi hành ra bến cảng Tuần Châu làm thủ tục lên tàu tham quan vịnh Hạ Long – di sản thiên nhiên thế giới với muôn vàn đảo đá sống động. Quý khách tham quan: Động Thiên Cung – một trong những hang động đẹp nhất của vịnh Hạ Long, bảo tàng mỹ thuật của nhũ đá, hòn Chó đá, đỉnh Lư Hương… Quý khách dùng cơm trưa trên tàu. \r\n- 11h30: Kết thúc hành trình tàu đưa quý khách cập bến, xe đón quý khách khởi hành về khách sạn nhận phòng nghỉ ngơi.\r\n- Chiều 15h00: Quý khách tham gia chương trình Team building “VƯỢT SÓNG VƯƠN XA” do  tổ chức với các game show liên hoàn gắn kết đồng đội, cùng nhau vượt qua mọi khó khan thử thách để bước tới vinh quang. \r\n- 17h00: Kết thúc chương trình, quý khách tự do tham quan tắm biển.\r\n- Tối 19h00: Quý khách dùng cơm tối tại nhà hàng. Sau bữa tối quý khách tự do tham quan khám phá Hạ Long về đêm\r\nNGÀY 03: SUN WORLD HẠ LONG PARK\r\n- Sáng: Quý khách dậy sớm ngắm cảnh bình minh trên vịnh Hạ Long, tắm biển.\r\n- 07h00 – 8h00: Quý khách dùng điểm tâm Buffet tại nhà hàng. Sau bữa sáng xe đón quý khách khởi hành tham quan, khám phá Sun World Hạ Long Park, là tổ hợp vui chơi giải trí hàng đầu Việt Nam với tổng diện tích lên tới 214ha. Tổ hợp được thiết kế bao gồm 02 phân khu chính: Phân khu giải trí ven biển và phân khu giải trí Ba Đèo được kết nối bởi hệ thống cáp theo Nữ Hoàng độc đáo. Hệ thống trò chơi hiện đại, đẳng cấp cùng với không gian kỳ vĩ của vịnh Hạ Long chắc chắn sẽ mang tới cho du khách những trải nghiệm khó quên. (Không bao gồm vé).\r\n- Trưa 11h00: Quý khách làm thủ tục trả phòng khách sạn. Dùng cơm trưa tại nhà hàng. \r\n- 13h00: Xe đón quý khách khởi hành về Hà Nội.\r\n- Tối 18h30: Về tới Hà Nội, HDV chia tay đoàn và hẹn gặp lại đoàn trong những chuyến đi sau.', 1, 1),
(20, 'HÀ NỘI – PHÚ QUỐC “THIÊN ĐƯỜNG NƠI HẠ GIỚI”', 1600, './img/sp20.jpg', '- Sáng: Quý khách dậy sớm ngắm cảnh bình minh trên đảo ngọc, hòa mình cùng làn nước biển trong xanh.\r\n- 07:00 – 08:00: Quý khách dùng điểm tâm Buffet sáng tại khách sạn. Sau bữa sáng xe đón quý khách tự do tham quan, đi chợ mua đặc sản Phú Quốc về làm quà cho người thân.\r\n- Trưa 11:00: Quý khách làm thủ tục trả phòng khách sạn, dùng cơm trưa tại nhà hàng.\r\n- 12:30: Xe đón quý khách khởi hành ra sân bay làm thủ tục trên chuyến bay của hãng hàng không VN Airlines / VJ… về Hà Nội. Tới sân bây Nội Bài xe đón quý khách khởi hành về điểm xuất phát ban đầu. HDV chia tay đoàn và hẹn gặp lại đoàn trong những chuyến đi sau.', 1, 1),
(21, 'TOUR SAPA - LAO CHẢI - TẢ VAN', 1100, './img/sp21.jpg', 'Qúy khách đi bộ tham quan bản Cát Cát., bắt đầu hành trình khám phá bản làng\r\n\r\nTham quan bản Cát Cát – Sín Chải của người H’mong. Du khách sẽ được thăm và tìm hiểu phong tục tập quán sinh hoạt kỳ thú, đơn sơ đến bình dị của những người dân tộc thiểu số\r\n\r\nTham quan thác Cát Cát và nhà máy thuỷ điện do người Pháp xây dựng đầu thế kỷ XX, vui chơi và chụp hình lưu niệm…\r\n\r\nQúy khách tự do tham quan: Chợ Sa Pa– nơi trao đổi mua bán nhiều loại hàng hóa, sản phẩm địa phương.\r\n\r\nTối: Ăn tối và nghỉ đêm tại Sa Pa. Đặc biệt vào tối thứ bảy Quý khách có thể tự do tham dự phiên Chợ Tình của người Dao Đỏ – một trong những nét văn hoá đặc sắc của các dân tộc vùng cao phía bắc Việt Nam.', 1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `fullname`, `password`, `phone`, `email`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Nun', 'trung', '123456789', '971845221', 'haha@gmail.com', 'HaNoi', '2023-12-21 08:27:10', '2023-12-21 08:31:43'),
(2, NULL, NULL, '$2y$12$B7.1BIdwhE9iTYUIQI1HjuQwf0CvYinF2y4QlyGQvAABUG88DgMKi', NULL, 'trungaming3@gmail.com', NULL, '2023-12-21 02:47:46', '2023-12-21 02:47:46'),
(4, NULL, NULL, '$2y$12$zwmkmTOznjfDV8.qAiAlbev6a.BLEzMwGL.Ck.6OZI2w1mJ9Kg3ta', NULL, 'admin@gmail.com', NULL, '2023-12-21 10:10:27', '2023-12-21 10:10:27'),
(5, NULL, NULL, '$2y$12$1s0b0mrNLiedulIDCPvbduol2P.9c8sedE4ZxtnfriTkQeyWGM2lq', NULL, 'kazuto1362002@gmail.com', NULL, '2023-12-21 10:24:10', '2023-12-21 10:24:10'),
(6, NULL, NULL, '$2y$12$OkqqAByz1tUDqyzMeuV.Qe.BEan5R0r1/YFt0HfiHwexVx/h2JQ.S', NULL, 'gunmahem@gmail.com', NULL, '2023-12-21 22:14:21', '2023-12-21 22:14:21'),
(7, NULL, NULL, '$2y$12$PJKpsTyiySi6RWzsU7nqAOSAa0ZBLSaO0Um8Y4RkTqHf7d8I3kkpG', NULL, 'namga@gmail.com', NULL, '2023-12-21 23:52:15', '2023-12-21 23:52:15'),
(8, NULL, NULL, '$2y$12$VqtbDYVZN9KaThUQx9JsPuLwuTDb7L4pPL8c5SJ24QSMLod9hWqMu', NULL, 'tester@gmail.com', NULL, '2023-12-22 04:21:59', '2023-12-22 04:21:59');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tour_id` (`tour_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `tour`
--
ALTER TABLE `tour`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manager_id` (`manager_id`),
  ADD KEY `users_id` (`users_id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `managers`
--
ALTER TABLE `managers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tour`
--
ALTER TABLE `tour`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `fk_account_id` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_account_managerid` FOREIGN KEY (`id`) REFERENCES `managers` (`id`);

--
-- Các ràng buộc cho bảng `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`tour_id`) REFERENCES `tour` (`id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `tour`
--
ALTER TABLE `tour`
  ADD CONSTRAINT `tour_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `managers` (`id`),
  ADD CONSTRAINT `tour_ibfk_2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
