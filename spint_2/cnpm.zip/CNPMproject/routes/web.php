<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\homepageController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\arlertController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\SendEmailController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/', [homepageController::class, 'index']);
Route::get('/search', [homepageController::class, 'search'])->name('search');
Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/alert', [arlertController::class, 'alert']);
Route::get('/detail/{id}', [homepageController::class, 'show'])->name('detail');


// Admin
Route::get('/admin', function() {
    return view('admin/admin');
})->middleware('checklogin::class');

Route::get('/adminadd', function() {
    return view('admin/adminadd');
});

Route::get('/admin', [AdminController::class, 'index'])->name('admin');

Route::get('/adminadd', [AdminController::class, 'create'])->name('adminadd');

Route::post('/adminadd/store', [AdminController::class, 'store']);

Route::delete('/admin/delete/{id}', [AdminController::class, 'destroy']);

Route::get('/payment',function(){
    return view('/payment');
});

Route::get('/payment', [SendEmailController::class, 'show']);

Route::post('/', [SendEmailController::class, 'sendmail']);