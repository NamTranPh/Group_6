<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('https://bcp.cdnchinhphu.vn/Uploaded/duongphuonglien/2020_09_24/giai%20nhat%20thuyen%20hoa.jpg') center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            width: 80%;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        }

        .card {
            border: none;
            margin-top: 20px;
        }

        .card-header {
            background-color: #3490dc;
            color: #fff;
            font-weight: bold;
            border-bottom: none;
            text-align: center;
            padding: 15px 0;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            text-align: center;
        }

        .alert {
            margin-bottom: 20px;
        }

        .nav {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            border-radius: 6px;
            padding: 0px;
        }

        .nav-link {
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 1100px;
        }

        .nav-link:hover {
            background-color: #45a049;
            color: #fff;
        }
    </style>
</head>
<body>
     
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Thông báo')); ?></div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php echo e(__('Chúc mừng bạn đã đăng kí/đăng nhập thành công!')); ?> <br>
                        <?php echo e(__('Vui lòng bấm vào nút để qua trang chủ!')); ?>

                    </div>
                    <button class="nav">
                        <a class="nav-link" href="/">Trang chủ</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\ki1_nam2\BaiTapLonCNPM\BTL_Group_6\code\CNPMproject\resources\views/home.blade.php ENDPATH**/ ?>