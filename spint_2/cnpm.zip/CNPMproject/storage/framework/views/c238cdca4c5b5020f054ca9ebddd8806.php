<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    body {
        font-family: 'Arial', sans-serif;
        background: url('https://bcp.cdnchinhphu.vn/Uploaded/duongphuonglien/2020_09_24/giai%20nhat%20thuyen%20hoa.jpg') center center fixed;
        background-size: cover;
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .container {
       
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    .card {
        border: none;
    }

    .card-header {
        background-color: #3490dc;
        color: #fff;
        font-weight: bold;
        border-bottom: none;
    }

    .card-body {
        text-align: center;
    }

    .alert {
        margin-bottom: 20px;
    }

    button {
        background-color: #4caf50;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button:hover {
        background-color: #45a049;
    }
    .a{
        width: 600px;
    }
</style>

</head>

<body>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="a row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo e(__('Chúc mừng bạn đã đăng nhập thành công!')); ?> <br>
                    <?php echo e(__('Vui lòng bấm vào nút để qua trang chủ!')); ?>

                </div>
                <button>
                    <a class="nav-link" href="/">Trang chủ</a>
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

</body>

</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ki1_nam2\BaiTapLonCNPM\BTL_Group_6\code\CNPMproject\resources\views/alert.blade.php ENDPATH**/ ?>