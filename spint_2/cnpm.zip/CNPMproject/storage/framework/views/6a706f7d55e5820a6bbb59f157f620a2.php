<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin/admin.css')); ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>

  <main class="main-wrapper">
    <div id="mainNavbar" class="sidebar-wrapper ">
      <!--  SIDEBAR  -->
      <div class="sidebar-logo">
        <img src="https://pos.nvncdn.com/86c7ad-50310/art/artCT/20230420_0moA6KAt.png" height="70px" alt="">
        <p class="brand-name">Festivals</p>
      </div>
      <ul class="nav-block">
        <li class="nav-title" style="font-weight:700;">
          ADMIN
        </li>
        <li class="nav-item nav-active">
          <a href="/admin">Trang chủ Admin</a>
        </li>
        <li class="nav-item">
          <a href="/adminadd">Thêm sản phẩm</a>
        </li>
        <li class="nav-item" style="background-color: rgba(227, 56, 56, 0.56);">
          <a href="/">Trang chủ</a>
        </li>
      </ul>
      
    </div>
    <div class="content-wrapper">
      <!-- CONTENT -->
      <div class="header-wrapper">
        <div class="products">
          <h3 class="products-title">Danh sách sản phẩm</h3>
        </div>
      </div>
      <div class="pro">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Tên Tour</th>
              <th scope="col">Giá</th>
              <th scope="col">Ảnh</th>
              <th cope="col">Chức năng</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->tourname); ?></td>
                <td><?php echo e($row->price); ?></td>
                <td><?php echo e($row->images); ?></td>
                <td>
                  <form action="/admin/delete/<?php echo e($row->id); ?>" method="POST" onsubmit="return ConfirmDelete( this )">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                      <button class="btn-delete" type="submit">Xóa</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <script src="<?php echo e(asset('js/admin/main.js')); ?>"></script>
</body>

</html><?php /**PATH D:\ki1_nam2\BaiTapLonCNPM\CNPMproject\CNPMproject\resources\views/admin/admin.blade.php ENDPATH**/ ?>