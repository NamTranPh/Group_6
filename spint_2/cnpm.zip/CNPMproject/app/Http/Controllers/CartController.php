<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Darryldecode\Cart\Facades\CartFacade as Cart;
class CartController extends Controller
{
    public function cartList(){
        $CartItems= Cart::getContent();
        return view('/cart',compact('CartItems'));
    }
    // Add
    public function addtoCart(Request $request) {
        Cart::add([
            'id' => $request->id,
            'name' => $request->tourname,
            'price' => $request->price,
            'quantity'=> $request->quantity,
            'attributes' => array(
                'images' =>$request->images,
            )
        ]);
        return redirect()-> route('Cart');
        // return redirect()->back()->with('success', 'Thêm sản phẩm vào giỏ hàng thành công!');
    }

    //Update
    // public function updateCart (Request $request, $id){
    //     $action = $request->input('action');
    //     if($action === 'add'){
    //         $request[$id]['quantity'] +=1;
    //     } elseif ($action === 'minus' && $request[$id]['quantity'] > 1){
    //         $request[$id]['quantity'] -=1;
    //     }

    //     return redirect()-> route('Cart');
    // }

    public function updateCart (Request $request){
        Cart::update($request->id,
            [
                'quantity' => [
                    'relative' => false,
                    'value' => $request->quantity
                ],
            ]);
        return redirect()-> route('Cart');
    }

    //Remove 
    public function removeCart (Request $request){
        Cart::remove($request->id);
        return redirect()-> route('Cart');
        // return back()->with('success', 'Xóa sản phẩm khỏi giỏ hành thành công!');
    }
}
